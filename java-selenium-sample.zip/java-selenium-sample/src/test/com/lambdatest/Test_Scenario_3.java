package com.lambdatest;

import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Test_Scenario_3 {
	private RemoteWebDriver driver;
	private String Status = "failed";

	@SuppressWarnings("deprecation")
	@BeforeMethod
	public void setup(Method m, ITestContext ctx) throws MalformedURLException {
		String username = "konda_yedukondalu";
		String authkey = "LT_vUcX2L8NvDfTmUTc4JQwBNyJlvUhhUp0DoeK09QPgtfFZQ0";

		String hub = "@hub.lambdatest.com/wd/hub";
		ChromeOptions browserOptions = new ChromeOptions();
		browserOptions.setPlatformName("Windows 10");
		browserOptions.setBrowserVersion("128.0");
		HashMap<String, Object> ltOptions = new HashMap<String, Object>();
		ltOptions.put("visual", true);
		ltOptions.put("video", true);
		ltOptions.put("network", true);
		ltOptions.put("build", "LambdaTest");
		ltOptions.put("project", "Selenium java 101");
		ltOptions.put("name", "Input Form Submit Test");
		ltOptions.put("console", "info");
		ltOptions.put("selenium_version", "4.0.0");
		ltOptions.put("w3c", true);
		browserOptions.setCapability("LT:Options", ltOptions);

		driver = new RemoteWebDriver(new URL("https://" + username + ":" + authkey + hub), browserOptions);

	}

	@SuppressWarnings("deprecation")
	@Test
	public void InputFormSubmitTest() throws InterruptedException {

		String Name = "Harsh Vardhan Singh";
		String email = "harshvardhanec1042@gmail.com";
		String password = "test@1234";
		String company = "test comp";
		String compemail = "testcomp.user@test.com";
		String country = "United States";
		String city = "NY";
		String address1 = "Addr1";
		String address2 = "Addr2";
		String state = "other";
		String zipcode = "12345";
		String successMsg = "Thanks for contacting us, we will get back to you shortly.";

		System.out.println("Loading Url");
		driver.executeScript(
				"lambdatest_executor: {\"action\": \"stepcontext\", \"arguments\": {\"data\": \"Opening WebApp\", \"level\": \"info\"}}");

		driver.get("https://www.lambdatest.com/selenium-playground/");

		driver.executeScript(
				"lambdatest_executor: {\"action\": \"stepcontext\", \"arguments\": {\"data\": \"Checking List Items\", \"level\": \"info\"}}");

		System.out.println("Goto 'Input Form Submit' page");
		driver.findElement(By.xpath("//a[.='Input Form Submit']")).click();
		System.out.println("Click Submit Button without input fields");
		driver.findElement(By.xpath("//button[text()='Submit'] ")).click();

		System.out.println("validate Error Message");
		WebElement activeElement = driver.switchTo().activeElement();
		String messageStr = activeElement.getAttribute("validationMessage");
		Assert.assertEquals("Please fill out this field.", messageStr);
		System.out.println("Enter Name");
		WebElement Nametxt = driver.findElement(By.xpath("//input[@id='name']"));
		Nametxt.sendKeys(Name);
		System.out.println("Enter Email");
		WebElement Emailtxt = driver.findElement(By.id("inputEmail4"));
		Emailtxt.sendKeys(email);

		System.out.println("Enter Password");
		WebElement Passwordtxt = driver.findElement(By.name("password"));
		Passwordtxt.sendKeys(password);

		System.out.println("Enter Company");
		WebElement Companytxt = driver.findElement(By.xpath("//input[@id='company']"));
		Companytxt.sendKeys(company);

		System.out.println("Enter Company Email");
		WebElement Companyemtxt = driver.findElement(By.xpath("//input[@id='websitename']"));
		Companyemtxt.sendKeys(compemail);

		System.out.println("Select county from dropdown");
		WebElement Country = driver.findElement(By.xpath("//select[@name='country']"));
		Select countydd = new Select(Country);
		countydd.selectByVisibleText(country);

		System.out.println("Enter City Email");
		WebElement Citytxt = driver.findElement(By.cssSelector("#inputCity"));
		Citytxt.sendKeys(city);

		System.out.println("Enter Address 1");
		WebElement Addr1txt = driver.findElement(By.cssSelector("#inputAddress1"));
		Addr1txt.sendKeys(address1);

		System.out.println("Enter Address 2");
		WebElement Addr2txt = driver.findElement(By.cssSelector("#inputAddress2"));
		Addr2txt.sendKeys(address2);

		System.out.println("Enter State");
		WebElement Statetxt = driver.findElement(By.id("inputState"));
		Statetxt.sendKeys(state);

		System.out.println("Enter Zipcode");
		WebElement Zipcodetxt = driver.findElement(By.name("zip"));
		Zipcodetxt.sendKeys(zipcode);

		System.out.println("Click Submit Again");
		driver.findElement(By.xpath("//button[text()='Submit'] ")).click();

		System.out.println("Validate Message");
		WebElement Message = driver.findElement(By.xpath("//p[@class='success-msg hidden']"));
		String MsgOutput = Message.getText().trim();
		Assert.assertEquals(successMsg, MsgOutput);
		Status = "passed";

		System.out.println("TestFinished");
	}

	@AfterMethod
	public void tearDown() {
		driver.executeScript(
				"lambdatest_executor: {\"action\": \"stepcontext\", \"arguments\": {\"data\": \"Adding Test Result and Closing Browser\", \"level\": \"info\"}}");
		driver.executeScript("lambda-status=" + Status);
		driver.quit();
	}
}
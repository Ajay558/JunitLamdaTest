package com.lambdatest;

import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Test_Scenario_2 {

	private RemoteWebDriver driver;
	private String Status = "failed";

	@BeforeMethod
	public void setup(Method m, ITestContext ctx) throws MalformedURLException {
		String username = "konda_yedukondalu";
		String authkey = "LT_vUcX2L8NvDfTmUTc4JQwBNyJlvUhhUp0DoeK09QPgtfFZQ0";

		String hub = "@hub.lambdatest.com/wd/hub";

		ChromeOptions browserOptions = new ChromeOptions();
		browserOptions.setPlatformName("Windows 10");
		browserOptions.setBrowserVersion("128.0");
		HashMap<String, Object> ltOptions = new HashMap<String, Object>();
		ltOptions.put("visual", true);
		ltOptions.put("video", true);
		ltOptions.put("network", true);
		ltOptions.put("build", "LambdaTest");
		ltOptions.put("project", "Selenium java 101");
		ltOptions.put("name", "Simple Form Demo Test");
		ltOptions.put("console", "info");
		ltOptions.put("selenium_version", "4.0.0");
		ltOptions.put("w3c", true);
		ltOptions.put("project", "Untitled");
		ltOptions.put("selenium_version", "4.0.0");
		browserOptions.setCapability("LT:Options", ltOptions);

		driver = new RemoteWebDriver(new URL("https://" + username + ":" + authkey + hub), browserOptions);

	}

	@Test
	public void DragDropSliders() throws InterruptedException {
		System.out.println("Loading Url");
		driver.executeScript(
				"lambdatest_executor: {\"action\": \"stepcontext\", \"arguments\": {\"data\": \"Opening WebApp\", \"level\": \"info\"}}");

		driver.get("https://www.lambdatest.com/selenium-playground/");
		driver.executeScript(
				"lambdatest_executor: {\"action\": \"stepcontext\", \"arguments\": {\"data\": \"Checking List Items\", \"level\": \"info\"}}");

		System.out.println("Goto 'Drag and Drop Sliders' page");
		driver.findElement(By.xpath("//a[text()='Drag & Drop Sliders']")).click();
		Thread.sleep(1000);

		WebElement slider = driver.findElement(By.xpath("//input[@value='15']"));

		Actions a = new Actions(driver);
		a.dragAndDropBy(slider, 215, 0).perform();
		Thread.sleep(2000);

		WebElement slider_now = driver.findElement(By.xpath("//output[@id='rangeSuccess']"));
		System.out.println("New Location :" + slider_now.getText());

		Status = "passed";

		System.out.println("TestFinished");
	}

}

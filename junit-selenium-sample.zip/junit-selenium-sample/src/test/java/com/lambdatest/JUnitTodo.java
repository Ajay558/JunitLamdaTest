package com.lambdatest;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;


import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

import junit.framework.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.*;
import java.util.HashMap;
import java.util.Map;

public class JUnitTodo {
	 String username = "thakur_singh1";
	    String accesskey = "ftcmbLN5yN1PzMMTJt5JkheTkqlgz0K2pCdn8x3u9sp7ja5WaJ";
	    static RemoteWebDriver driver = null;
	    String gridURL = "@hub.lambdatest.com/wd/hub";
	    boolean status = false;

    /*
    Steps to run Smart UI project (https://beta-smartui.lambdatest.com/)
    Step - 1 : Change the hub URL to @beta-smartui-hub.lambdatest.com/wd/hub
    Step - 2 : Add "smartUI.project": "<Project Name>" as a capability above
    Step - 3 : Add "driver.executeScript("smartui.takeScreenshot");" code wherever you need to take a screenshot
    Note: for additional capabilities navigate to https://www.lambdatest.com/support/docs/test-settings-options/
     */

   // public String gridURL = "@hub.lambdatest.com/wd/hub";
    //public String status;

    @Before
    public void setUp() throws Exception {
    	 DesiredCapabilities capabilities = new DesiredCapabilities();
         capabilities.setCapability("browserName", "chrome");
         capabilities.setCapability("version", "70.0");
         capabilities.setCapability("platform", "win10"); // If this cap isn't specified, it will just get the any available one
         capabilities.setCapability("build", "LambdaTestSampleApp");
         capabilities.setCapability("name", "LambdaTestJavaSample");
         try {
             driver = new RemoteWebDriver(new URL("https://" + username + ":" + accesskey + gridURL), capabilities);
         } catch (MalformedURLException e) {
             System.out.println("Invalid grid URL");
         } catch (Exception e) {
             System.out.println(e.getMessage());
         }
    }

    @Test
    public void testSimple() throws Exception {
        try {
        	// Click on "Radio Buttons Demo"
        	driver.get("https://www.lambdatest.com/selenium-playground/");
             driver.findElement(By.linkText("Radio Buttons Demo")).click();

             // Select "Female" radio button
             WebElement femaleRadioButton = driver.findElement(By.xpath("//input[@value='Female' and @name='gender']"));
             femaleRadioButton.click();
             
             // Click "Get value" button
             driver.findElement(By.id("buttoncheck")).click();

             // Get the displayed message
             WebElement message = driver.findElement(By.className("radiobutton"));
             String actualText = message.getText();
             
             // Assertion
             Assert.assertEquals("Radio button 'Female' is checked", actualText);
           
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
    @Test
    public void testWindowPopupModal() {
        // Explicit wait for page load
    	//wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        //wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText("Window Popup Modal")));

        // Click on "Window Popup Modal"
    	driver.get("https://www.lambdatest.com/selenium-playground/");
        driver.findElement(By.linkText("Window Popup Modal")).click();

        // Click "Follow On Twitter" button
        WebElement twitterButton = driver.findElement(By.xpath("//a[contains(text(),'Follow On Twitter')]"));
        twitterButton.click();

        // Validate new window opened
        String mainWindowHandle = driver.getWindowHandle();
        Set<String> allWindowHandles = driver.getWindowHandles();
        Assert.assertTrue("New window should be opened", allWindowHandles.size() > 1);

        // Close all windows
        for (String handle : allWindowHandles) {
            driver.switchTo().window(handle);
            driver.close();
        }
    }
    
    @After
    public void tearDown() throws Exception {
        if (driver != null) {
            driver.executeScript("lambda-status=" + status);
            driver.quit();
        }
    }
}

